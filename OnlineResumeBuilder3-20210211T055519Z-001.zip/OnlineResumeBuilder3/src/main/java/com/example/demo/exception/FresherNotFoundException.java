package com.example.demo.exception;

public class FresherNotFoundException extends RuntimeException{
public FresherNotFoundException(String msg) {
	super(msg);
}
}
