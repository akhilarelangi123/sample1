package com.example.demo.exception;

public class AdminIdExceptionResponse {
	private String id;

	

	public AdminIdExceptionResponse(String id) {
		this.id=id;
	}

	public String getId() {
		return id;
	}
}
