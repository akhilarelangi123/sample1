package com.example.demo.exception;

public class ResumeNotFoundException extends RuntimeException {
	
	public ResumeNotFoundException(String message) {
        super(message);
    }
}
