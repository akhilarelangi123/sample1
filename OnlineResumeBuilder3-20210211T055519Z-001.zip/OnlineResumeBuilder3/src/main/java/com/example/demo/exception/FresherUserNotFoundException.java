
package com.example.demo.exception;

public class FresherUserNotFoundException extends RuntimeException{
public FresherUserNotFoundException(String msg) {
	super(msg);
}
}
