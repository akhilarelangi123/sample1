
package com.example.demo.exception;

public class ExperiencedUserNotFoundException extends RuntimeException{
	public ExperiencedUserNotFoundException(String msg) {
		super(msg);
	}
	}